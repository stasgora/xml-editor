
package mf.org.w3c.dom.svg;

public interface SVGAnimatedRect {
  public SVGRect getBaseVal( );
  public SVGRect getAnimVal( );
}
