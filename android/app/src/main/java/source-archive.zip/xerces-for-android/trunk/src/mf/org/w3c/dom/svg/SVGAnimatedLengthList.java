
package mf.org.w3c.dom.svg;

public interface SVGAnimatedLengthList {
  public SVGLengthList getBaseVal( );
  public SVGLengthList getAnimVal( );
}
