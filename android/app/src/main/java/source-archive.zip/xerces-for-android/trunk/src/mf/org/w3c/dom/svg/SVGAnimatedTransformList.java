
package mf.org.w3c.dom.svg;

public interface SVGAnimatedTransformList {
  public SVGTransformList getBaseVal( );
  public SVGTransformList getAnimVal( );
}
