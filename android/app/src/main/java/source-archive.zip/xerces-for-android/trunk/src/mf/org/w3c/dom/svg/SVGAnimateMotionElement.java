
package mf.org.w3c.dom.svg;

public interface SVGAnimateMotionElement extends 
               SVGAnimationElement {
}
