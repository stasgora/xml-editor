
package mf.org.w3c.dom.svg;

public interface SVGMissingGlyphElement extends 
               SVGElement,
               SVGStylable {
}
